## 交易系统全局规则

### 职责隔离（不可违反）
- 研究员只能访问 intel_mcp，不可调用 risk_mcp 和 exec_mcp
- 策略员只能访问 intel_mcp，不可调用 risk_mcp 和 exec_mcp
- 风控员可访问 risk_mcp 和 exec_mcp（只读），不可下单和撤单
- 执行员只能访问 exec_mcp，不可调用 intel_mcp 和 risk_mcp
- 复盘员可访问 intel_mcp 和 exec_mcp（只读），不可下单和撤单
- 研究员不可直接下单，执行员不可自行决定买什么

### 数据契约
- 所有 agent 之间传递交易意图必须使用 TradeIntent JSON 格式
- TradeIntent 必填字段：symbol, market, direction
- approval_status 只能由风控员设置，其他 agent 不可修改

### 风控硬规则（由 risk_mcp 服务端强制执行）
- T+1：当日买入标的不可当日卖出
- 涨停不追买（涨幅 >= 9.8%，ST 为 4.8%）
- 跌停不抄底（跌幅 <= -9.8%，ST 为 -4.8%）
- 单票持仓不超过总资产 20%
- 单行业持仓不超过总资产 40%
- 当日累计亏损超过总资产 3%，暂停所有交易
- ST / 停牌 / 退市风险标的禁止交易
- 非交易时段（9:30-11:30, 13:00-15:00 之外）禁止下单
- 集合竞价时段（9:15-9:25, 14:57-15:00）仅允许限价单
- 近5日日均成交额 < 1000万的标的禁止交易
- 委托数量必须为 100 的整数倍

### 执行规则
- ⚠️ V0 阶段所有下单操作为 dangerous，需主人确认后才可执行
- ❌ 禁止未经风控 approved 的 intent 进入执行环节
- ❌ 禁止执行员自动重试失败的委托
- ❌ 禁止任何 agent 修改风控员的 rejected 决定为 approved

### TradeIntent 标准格式                                            
所有 agent 之间传递交易意图必须使用以下 JSON Schema：              
{symbol, market, thesis, direction, confidence, entry_rule,        
exit_rule,                                                         
max_position_pct, time_horizon, valid_until, risk_notes,          
tool_evidence, approval_status}